package Battleships;

public class square
{
    private static boolean isTried;
    private Ship ship;

    public Ship getShip()
    {
        return ship;
    }

    public void setShip(Ship ship)
    {
        this.ship = ship;
    }



    public static boolean isTried()
    {
        return isTried;
    }

    public static void setTried(boolean tried)
    {
        isTried = tried;
    }

    public boolean isHit(){
        return isTried && this.ship != null;
    }

    public boolean isMiss(){
        return isTried && this.ship == null;
    }



    public String getCodeCharacter(boolean showShips)
    {
        if (isTried)
        {
            if(this.isHit())
            {
                return "*";
            }
            else if (this.isMiss())
            {
                return "'";
            }

        }
        else {
            if (showShips && this.ship != null) {
                return this.ship.getCode();
            }
        }

        return "~";
    }


}

