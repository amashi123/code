package Battleships;

public class FailedToPlaceShipException extends RuntimeException
{

}
