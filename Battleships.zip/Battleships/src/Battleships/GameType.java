package Battleships;

public enum GameType {
    HUMAN_V_HUMAN,
    HUMAN_V_COMPUTER,
    COMPUTER_V_COMPUTER
}