package Battleships;

import Battleships.ships.Aeroplane;
import Battleships.ships.AircraftCarrier;
import Battleships.ships.Battleship;
import Battleships.ships.SimpleShip;

public class ShipDemo
{
    public static void main(String[] args)
    {
        //Ship s = new SimpleShip ("Battleship","B",5);
        Ship s = new AircraftCarrier();

        System.out.println(s);
        s.rotate();
        System.out.println(s);
        s.rotate();
        System.out.println(s);
        s.rotate();
        System.out.println(s);
        s.rotate();
        System.out.println(s);


    }


}
