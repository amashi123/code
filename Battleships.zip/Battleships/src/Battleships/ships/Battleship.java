package Battleships.ships;

import Battleships.Ship;

public class Battleship extends SimpleShip
{

    public Battleship() {
        super("battleship","B",5);
    }
}
