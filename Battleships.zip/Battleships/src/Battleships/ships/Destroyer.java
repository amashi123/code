package Battleships.ships;

import Battleships.Ship;

public class Destroyer extends SimpleShip
{

    public Destroyer()
    {
        super("destroyer","D",4);
    }
}
