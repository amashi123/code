package Battleships.ships;

import Battleships.Ship;

public class Submarine extends SimpleShip
{

    public Submarine() {
        super("submarine","S",3);
    }
}
