public class FailedToPlaceShipException extends RuntimeException
{

}
